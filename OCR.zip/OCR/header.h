#ifndef HEADER_H
#define HEADER_H


class header
{
public:
    header();

signals:

public slots:
};

#endif // HEADER_H
